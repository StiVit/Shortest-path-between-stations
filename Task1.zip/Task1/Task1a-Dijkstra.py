from Graph import UndergroundMap  # Importing the class UndergroundMap from Graph.py
import networkx as nx

def dijkstra(G, s):
    """Solve single-source shortest-paths problem with no negative-weight edges.

    	Arguments:
    	G -- a directed, weighted graph
    	s -- index of source vertex
    	Assumption:
    	All weights are nonnegative

    	Returns:
    	d -- distances from source vertex s
    	pi -- predecessors
    	"""

    def initialize_single_source(G, s):
        d = {v: float('inf') for v in G.nodes}
        pi = {v: None for v in G.nodes}
        d[s] = 0
        return d, pi

    def relax(u, v, w, d, pi):
        if d[v] > d[u] + w:
            d[v] = d[u] + w
            pi[v] = u

    d, pi = initialize_single_source(G, s)
    S = []
    Q = list(G.nodes)
    while Q:
        u = min(Q, key=lambda v: d[v])  # Select the minimum distance vertex u from the nodes in Q
        Q.remove(u)  # Remove the minimum vertex u from Q
        S.append(u)  # Add vertex u to the set S
        for v in G.adj[u]:  # For each adjacent vertex v to u
            relax(u, v, G.edges[u, v]['weight'], d, pi)  # Relax the edge between u and v

    return d, pi

if __name__ == "__main__":
    map = UndergroundMap()  # Creating an instance of the UndergroundMap class from Graph.py
    map.create_data_base('London Underground data.xlsx')  # Load data into the graph from the provided Excel file
    london_underground_graph = map.get_graph()  # Get the graph representing the London Underground

    start_station_name = 'Holborn'
    end_station_name = 'Stratford'

    shortest_durations, predecessors = dijkstra(london_underground_graph, start_station_name)
    shortest_duration = shortest_durations[end_station_name]

    # Retrieve the path using predecessors
    path = [end_station_name]
    current = end_station_name
    while predecessors[current] is not None:
        path.append(predecessors[current])
        current = predecessors[current]
    path.reverse()

    # Output the results
    print(f"Shortest Duration: {shortest_duration} minutes")
    print(f"Shortest Path: {path}")
