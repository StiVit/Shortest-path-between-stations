import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt

class UndergroundMap():
    def __init__(self):
        self.graph = nx.Graph()

    def create_data_base(self, path):
        self.data_set = pd.read_excel(path)
        for index, row in self.data_set.iterrows():
            station1 = row[1]
            station2 = row[2]
            weight = float(row[3])  # Convert weight to a float if it's read as a string
            self.graph.add_edge(station1, station2, weight=weight)


    def get_graph(self):
        return self.graph

def dijkstra(graph, start_station):
    d = nx.single_source_dijkstra_path_length(graph, start_station, weight='weight')
    return d

# Create an UndergroundMap instance
map = UndergroundMap()

# Load data from the provided Excel file
map.create_data_base('London Underground data.xlsx')
london_underground_graph = map.get_graph()

# Create an empty list to store journey times between stations
all_journey_times = []

# Iterate through all stations to find shortest paths and populate the journey times list
for station in london_underground_graph.nodes:
    shortest_durations = dijkstra(london_underground_graph, station)
    all_journey_times.extend(shortest_durations.values())

# Generate a histogram of the journey times between station pairs
plt.hist(all_journey_times, bins=50, color='skyblue', edgecolor='black')
plt.xlabel('Journey Time (minutes)')
plt.ylabel('Frequency')
plt.title('Histogram_task1')
plt.grid(True)
plt.show()
