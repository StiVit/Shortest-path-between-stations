import pandas as pd
import networkx as nx

class UndergroundMap():
    def __init__(self):
        self.graph = nx.Graph()

    def create_data_base(self, path):
        self.data_set = pd.read_excel(path)
        for index, row in self.data_set.iterrows():
            station1 = row.iloc[1]
            station2 = row.iloc[2]
            weight = float(row.iloc[3])  # Convert weight to a float if it's read as a string
            self.graph.add_edge(station1, station2, weight=weight)

    def get_graph(self):
        return self.graph

if __name__ == "__main__":
    map = UndergroundMap()
    map.create_data_base('London Underground data.xlsx')
    graph = map.get_graph()

    shortest_path = nx.shortest_path_length(graph, source='Holborn', target='Mile End', weight='weight')
    print("Shortest travel time:", shortest_path)
    shortest_path = nx.shortest_path(graph, source='Holborn', target='Mile End', weight='weight')
    print("Shortest path:", shortest_path)
